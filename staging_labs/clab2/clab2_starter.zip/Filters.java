import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Filters {

  public static void main(String[] args)throws IOException {
    // TODO: modify this main method as you wish, to run and test your filter implementations.

    // Read in the image file.
    File f = new File("dog.png");
    BufferedImage img = ImageIO.read(f);

    // For debugging
    System.out.println("Before:");
    System.out.println(Utilities.getRGBArray(0, 0, img)[0]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[1]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[2]);
    // 93 43 47

    // Apply a filter implementation on img.
    applyGrayscale(img);

    // For debugging
    System.out.println("After:");
    System.out.println(Utilities.getRGBArray(0, 0, img)[0]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[1]);
    System.out.println(Utilities.getRGBArray(0, 0, img)[2]);
    // 58 58 58

    // Write the result to a new image file.
    f = new File("dog_filtered.png");
    ImageIO.write(img, "png", f);
  }

  public static void applyGrayscale(BufferedImage img) {
    // TODO
  }

  public static void applyNorak(BufferedImage img) {
    // TODO
  }

  public static void applyBorder(BufferedImage img, int borderThickness, int[] borderColor) {
    // TODO
  }

  public static void applyMirror(BufferedImage img) {
    // TODO
  }

  public static void applyBlur(BufferedImage img) {
    // TODO
  }

  public static void applyCustom(BufferedImage img) {
    // TODO
  }
}
