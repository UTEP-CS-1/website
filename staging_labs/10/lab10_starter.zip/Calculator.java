public class Calculator {

  public static void main(String[] args) {
    // TODO - call upon your methods to test them
  }

  public static int powerLoop(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int powerRecursive(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int multiplyLoop(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int multiplyRecursive(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int divideLoop(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int divideRecursive(int x, int y) {
    return -1;  // TODO - remove and implement
  }
}
