public class Calculator {

  public static void main(String[] args) {
    // TODO - call upon powerLoop with a base case input and print the result

    // TODO - call upon powerLoop with a non-base case input and print the result

    // TODO - call upon powerRecursive with a base case input and print the result

    // TODO - call upon powerRecursive with a non-base case input and print the result

    // TODO - call upon multiplyLoop with a base case input and print the result

    // TODO - call upon multiplyLoop with a non-base case input and print the result

    // TODO - call upon multiplyRecursive with a base case input and print the result

    // TODO - call upon multiplyRecursive with a non-base case input and print the result

    // TODO - call upon divideLoop with a base case input and print the result

    // TODO - call upon divideLoop with a non-base case input and print the result

    // TODO - call upon divideRecursive with a base case input and print the result

    // TODO - call upon divideRecursive with a non-base case input and print the result
    
  }

  public static int powerLoop(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int powerRecursive(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int multiplyLoop(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int multiplyRecursive(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int divideLoop(int x, int y) {
    return -1;  // TODO - remove and implement
  }

  public static int divideRecursive(int x, int y) {
    return -1;  // TODO - remove and implement
  }
}
