import java.util.Scanner;

public class RunningAverage {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    // TODO: Add your implementation below here.
    // The following lines are provided for you to modify and re-arrange.
    // More lines of code will need to be added.

    System.out.print("Enter another number to add to the running average: ");
    double input = scanner.nextDouble();
    System.out.println("Running average is: " + "FIXME");
  }
}
