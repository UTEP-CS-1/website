import java.util.Scanner;

class MinersFoodRecommendationService {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("How many dollars are you willing to spend? (type a positive integer): ");
		int A = scanner.nextInt();
		System.out.print("I would be interested in trying boba! (type true or false): ");
		boolean B = scanner.nextBoolean();
		System.out.print("I am addicted to warm rolls with cinnamon butter (type true or false): ");
		boolean C = scanner.nextBoolean();
		System.out.print("I am looking for a full meal as opposed to a pick-me-up snack (type true or false): ");
		boolean D = scanner.nextBoolean();

		// TODO: Add your code below here.
	}
}
