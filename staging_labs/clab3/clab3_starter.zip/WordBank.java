import java.io.FileNotFoundException;

public class WordBank {

  // Do not modify the method signature.
  public static boolean checkInDictionary(String proposed) throws FileNotFoundException {
    return false;  // TODO - implement and replace me
  }

  // Do not modify the method signature.
  public static String getAnswerForPuzzleNumber(int puzzleNumber) throws FileNotFoundException {
    return "fixme";  // TODO - implement and replace me
  }
}
