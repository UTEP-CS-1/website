public class WordleLetter {

	// TODO - implement according to spec

	// TODO - include the below code back in once rest of class is implemented.
	// Do not modify this method implementation.
	// public String toString() {
	// 	String colorCode;
	// 	if(color.equals("green")) {
	// 				colorCode = "\u001B[32m";
	// 		} else if(color.equals("yellow")) {
	// 				colorCode = "\u001B[33m";
	// 		} else {
	// 				colorCode = "\u001B[31m";
	// 		}
	//
	// 	String resetCode = "\u001B[0m";
	//
	// 	return String.format(
	// 		"%s %s %s",
	// 		colorCode, letter, resetCode);
	// }
}
