public class WordleGame {
    // TODO - implement according to spec
}
