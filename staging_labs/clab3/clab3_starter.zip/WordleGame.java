public class WordleGame {
  // TODO - implement according to spec

  // TODO - include the remainder of the below code back in once rest of class is implemented.
  // Do not modify this method implementation.
  public String toString() {
    // result will be used to build the full answer String
    String result = "";
  //   // for each word guessed so far
  //   for (int i = 0; i < getNumberGuessesSoFar(); i++) {
  //     // get each letter of each word
  //     for (int j = 0; j < 5; j++) {
  //       // concatenate it to the result
  //       // WordleLetter's toString() is automatically invoked here.
  //       result += getGuess(i)[j];
  //     }
  //     // new line separator between each word
  //     result += "\n";
  //   }
    return result;
  }
}
