import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

    //here is where you will take user input with a scanner
    //conver the input to the correct position in the array
    //Example input 1,3 -> should convert to 0,2 in the array 
    
    }
}
