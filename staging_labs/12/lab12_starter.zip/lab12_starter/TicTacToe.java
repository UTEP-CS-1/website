import java.util.Scanner;

public class TicTacToe {
    private char[][] board;
    private char currentPlayer;
    //Our size will always be set to a 3 by 3 board
    private int SIZE =3;
    public TicTacToe() {
        board = new char[3][3];
        currentPlayer = 'X';
        resetBoard();
    }


    //resets the array to blank -'s'
    public void resetBoard() {

    }


    //method to print the gameboard (2D array)
    public void displayBoard() {

    }


    // given the CORRECT row and col, print into your board the player piece (X or O),
    // return true if valid movement was made, or false if it cannot be made 
    //example, if player x has piece on 2,2, and player o tries 2,2 return false

    public boolean makeMove(int row, int col) {

        return false;
    }


    public boolean checkWin() {
        // Check rows

    
        // Check columns

    
        // Check diagonals
    
        // No win found
        return false;
    }    
    //method used to change from player X to 0
    public void changePlayer() {
    }


    //checks to see if the array has blanks left
    public boolean isBoardFull() {
        return false;
    }

    //Method to distinguish which player is making the move
    public char getCurrentPlayer() {
        return 'x'; ///Please change, x is here as a placeholder
    }
}

