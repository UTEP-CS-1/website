import java.util.Random;

public class ExploreElPaso {

  public static void main(String[] args) {
    Random randomGenerator = new Random(1101);

    System.out.print("Enter start (int): ");
    // TODO receive user input.
    System.out.print("Enter west end (int): ");
    // TODO receive user input.
    System.out.print("Enter east end (int): ");
    // TODO receive user input.
    System.out.print("Enter number of trials (positive int): ");
    // TODO receive user input.
    System.out.println();

    // Example usage of generating a random boolean.
    // TODO modify and use.
    boolean randomResult = randomGenerator.nextBoolean();

    // TODO your implementation here.

    // TODO replace FIXME and use.
    System.out.println("Average steps: " + "FIXME");
    System.out.println("Average chance of exiting west: " + "FIXME");
    System.out.println("Average chance of exiting east: " + "FIXME");
  }
}
