class PrimeFactorize {
  public static void main(String[] args) {
    System.out.print("Enter a positive integer to find its prime factorization: ");
    // TODO receive user input.

    // TODO your implementation here.
  }
}
