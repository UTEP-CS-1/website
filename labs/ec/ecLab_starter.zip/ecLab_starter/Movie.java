public class Movie{
	
	//Attributes

	//Constructors

	//Methods

	//Getters/Setters

}
