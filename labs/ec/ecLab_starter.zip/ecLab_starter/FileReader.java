public class FileReader {

	//Attributes

	//Constructors

	//Methods

	//Getters/Setters
}
