// Import what you will need


public class CalculatorStarter {
    public static void main(String[] args) throws FileNotFoundException {
        // TODO
        // Read the file
        
        // For every line in the file, call your method calculate perform the correct operation
    }

    // TODO
    // Write your method calculate here, refer to the instructions for how to do it!

    // Write your method add here

    // Write your method subtract here

    // Write your method multiply here

    // Write your method divide here

    // Write your method power here

    // Write your method factorial here

}

