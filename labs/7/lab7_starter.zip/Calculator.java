// Import what you will need

import java.io.FileNotFoundException;

public class Calculator {
    public static void main(String[] args) throws FileNotFoundException {
        // TODO
        // Read the file
        
        // For every line in the file, call your method calculate to calculate the correct result
    }

    // TODO
    // Write your method calculate here, refer to the instructions for how to do it!

    // Write your method add here

    // Write your method subtract here

    // Write your method multiply here

    // Write your method divide here

    // Write your method power here

    // Write your method factorial here

}

