public class Calculator {
	public static void main(String[] args) {

	}
}
