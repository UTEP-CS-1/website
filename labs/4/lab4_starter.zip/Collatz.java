
public class Collatz {
  public static void main(String[] args) {

    System.out.print("Enter the start of the Collatz sequence x (positive int): ");
    // TODO: initialize a variable to accept this input using a Scanner from System.in.
    // Refer to the lab slides from Lab 3 about using the Scanner.

    // TODO: your implementation here.

    System.out.println("\nNumber of steps: " + "FIXME");
  }
}
